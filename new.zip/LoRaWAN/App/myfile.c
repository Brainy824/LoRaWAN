
#include <stdio.h>
#include "string.h"
#include "main.h"
#include "subghz.h"
#include "region.h"
#include "LoRaMac.h"
#include "LmHandler.h"
#include "LoRaMacCrypto.h"

#include "stdint.h"
#include "lora_app.h"
#include "LmHandler.h"


uint8_t Send_Buffer[2] = {0x12,0x34};

static LmHandlerParams_t LoRaWANParams = {
    .ActiveRegion = LORAMAC_REGION_CN470,
    .DefaultClass = CLASS_A, 
    .AdrEnable = LORAMAC_HANDLER_ADR_OFF,
    .TxDatarate  = DR_2,
    .PingPeriodicity = 4,
};

static LmHandlerAppData_t app_Data = {
    .Buffer = Send_Buffer, 
    .BufferSize = 2,
    // .have_send = 1,
    .Port = 85,
};

uint8_t Dev_Eui[8] = {0x00,0x80,0xE1,0x01,0x01,0x01,0x01,0x01};
uint8_t App_Key[16] = {0x00,0x80,0xE1,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01};

static uint8_t AppDataBuffer[242];

static LmHandlerAppData_t AppData = { 1, 2, AppDataBuffer };

void My_LoRaWAN_Configure(void)
{
    LmHandlerConfigure(&LoRaWANParams);

}

void my_file(void)
{
    static bool first = true;
    LmHandlerMsgTypes_t confirm = 0;
    static LmHandlerErrorStatus_t send_status = 0;
    static uint32_t time;
    if (first == true || HAL_GetTick() - time > 10000) {
        time = HAL_GetTick();
    } else {
        return;
    }
    if(first == false && LoRaMacIsBusy() == true) {
        printf("The Mac is Busy\r\n");
    } else if(LmHandlerJoinStatus() == LORAMAC_HANDLER_RESET) {
        first = false;
        MibRequestConfirm_t mibReq = {0};

        /*打印DevEui & AppEui参数*/  
        mibReq.Type = MIB_DEV_EUI;
        LoRaMacMibGetRequestConfirm(&mibReq);
        printf( "Default DevEui      : %02X", mibReq.Param.DevEui[0] );
        for( int i = 1; i < 8; i++ ){
            printf( "-%02X", mibReq.Param.DevEui[i] );
        }
        printf( "\r\n" );

        /*打印 AppKey */
        mibReq.Type = MIB_APP_KEY; 
        LoRaMacMibGetRequestConfirm(&mibReq);
        printf( "AppKey      : %02X", mibReq.Param.AppKey[0] );
        for( int i = 1; i < 16; i++ ){
            printf( "-%02X", mibReq.Param.AppKey[i] );
        }
            printf( "\r\n" );

        /*打印 更改后AppKey */
        if(LmHandlerSetAppKey(App_Key) == LORAMAC_HANDLER_SUCCESS){
            printf("AppKey Set      : %02X",mibReq.Param.AppKey[0]);
             for( int i = 1; i < 16; i++){
            printf( "-%02X", mibReq.Param.AppKey[i] );
            }
            printf( "\r\n" );
        }
        else{
            printf("AppKey Set Failed\rn");
        }
        if(LmHandlerSetNwkKey(App_Key) == LORAMAC_HANDLER_SUCCESS){
            printf("AppKey Set      : %02X",mibReq.Param.NwkKey[0]);
             for( int i = 1; i < 16; i++){
            printf( "-%02X", mibReq.Param.NwkKey[i] );
            }
            printf( "\r\n" );
        }
        else{
            printf("AppKey Set Failed\r\n");
        }

        /*设置信道掩码*/
        int16_t chan_mask[6] = {0xffff, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000};
        mibReq.Type = MIB_CHANNELS_DEFAULT_MASK;
        mibReq.Param.ChannelsMask = chan_mask;



        if(LoRaMacMibSetRequestConfirm(&mibReq) != LORAMAC_STATUS_OK) {
            printf("LoRaMacMibSetRequestConfirm is failed\r\n");
        } else {
            printf("LoRaMacMibSetRequestConfirm is ok\r\n");
        }
        printf("here is netting\r\n");
        

        LmHandlerJoin(ACTIVATION_TYPE_OTAA);
        printf("LmHandlerJoin is ok\r\n");

        // LmHandlerErrorStatus_t status = LmHandlerSend(&AppData, 242, &nextTxIn, false);
        // HAL_Delay(1100);
        // printf("LmHandlerSend return : %d\r\n",status);
        // if(LORAMAC_HANDLER_SUCCESS == status) {
        //     printf("send succeed, data = %s\r\n", (char *)AppData.Buffer);
        // }
        // else if (nextTxIn > 0) {
        //     printf("Next Tx in  : %ld\r\n", (nextTxIn / 1000));
        // } else {
        //     printf("send failed, status = %d\r\n",status);
        // }

    } else {
        printf("The Lora network is connected\r\n");
        send_status = LmHandlerSend(&app_Data, confirm, 0, false);
        if(send_status == LORAMAC_HANDLER_SUCCESS)
        {
            for (uint8_t i = 0; i < app_Data.BufferSize; i++)
            printf("%02x", app_Data.Buffer[i]);
            printf("\r\n");
            printf("datasize      : %d\r\n", app_Data.BufferSize);
            printf("port          : %d\r\n", app_Data.Port);
            printf("confirm       : %d\r\n", confirm);
        }
    }
}

void lora_send_data(const char * fmt, ...)
{
    uint32_t nextTxIn = 0;
    AppData.Port = 2;

    va_list args;
    va_start(args, fmt);
    AppData.BufferSize = vsnprintf((char *)AppData.Buffer, 242, fmt, args);
    va_end(args);

    LmHandlerErrorStatus_t status = LmHandlerSend(&AppData, LORAWAN_DEFAULT_CONFIRMED_MSG_STATE, &nextTxIn, false);
    
    if(LORAMAC_HANDLER_SUCCESS == status) {
        printf("send succeed, data = %s", (char *)AppData.Buffer);
    }
    else if (nextTxIn > 0) {
        printf("Next Tx in  : ~%ld second(s)", (nextTxIn / 1000));
    } else {
        printf("send failed, status = %d",status);
    }
}

