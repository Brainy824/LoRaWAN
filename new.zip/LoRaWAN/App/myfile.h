#ifndef __MYFILE_H__
#define __MYFILE_H__
void My_LoRaWAN_Configure(void);
void my_file(void);
void lora_send_data(const char * fmt, ...);

#endif
