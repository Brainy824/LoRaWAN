# ATECC608A-TNGLORA secure element module support documents

[ATECC608A-TNGLORA](https://www.microchip.com/wwwproducts/en/ATECC608A-TNGLORA) acts as a HW secure element, see [The Things Industries reference repository](https://github.com/TheThingsIndustries/lorawan-example-atecc608a-tnglora) for further documentation and examples.
