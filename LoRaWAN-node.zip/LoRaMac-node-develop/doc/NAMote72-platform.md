# NAMote72 platform support documents

* [NAMote72](https://os.mbed.com/platforms/NAMote-72/)
